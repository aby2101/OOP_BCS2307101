const prayers = document.querySelectorAll('.prayer-list li');
const message = document.getElementById('message');
const pointsDisplay = document.getElementById('points');
const avatarsContainer = document.getElementById('avatars');
const doneButton = document.getElementById('doneButton');
let completedCount = 0;
let points = 0;
let avatarUnlocked = 0;

prayers.forEach(prayer => {
    prayer.addEventListener('click', () => {
        if (!prayer.classList.contains('completed')) {
            prayer.classList.add('completed');
            completedCount++;
        }
    });
});

doneButton.addEventListener('click', () => { 
    if (completedCount >= 5) {
        points += 10;
        checkAvatarReward();
        // Display message whenever user has earn 10 points.
        message.textContent = "Great job! You earned 10 points! 🌟";
        message.className = "success";
    } else {
        // Display message whenever user cannot earn points.
        message.textContent = "Sorry, you can't get 10 points since you were not complete your solah 🙁";
        message.className = "error";
    }
    // To display current points.
    pointsDisplay.textContent = `Points: ${points}`;
    completedCount = 0;
    prayers.forEach(prayer => prayer.classList.remove('completed'));
});

function checkAvatarReward() {
    // Code to unlock new avatar every +50 points
    if (points % 50 === 0) {
        avatarUnlocked++;
        let newAvatar = document.createElement('img');
        newAvatar.classList.add('avatar');
        // Insert API link to get avatar.
        newAvatar.src = `https://api.dicebear.com/7.x/bottts/svg?seed=Avatar${avatarUnlocked}`;
        avatarsContainer.appendChild(newAvatar);
    }
}